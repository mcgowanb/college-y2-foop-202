﻿
namespace AWExample
{
    using System;
    using System.Collections.Generic;

    public partial class SalesOrderDetail
    {

    }
}
